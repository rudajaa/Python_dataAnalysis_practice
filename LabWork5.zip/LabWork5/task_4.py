import pandas as pd

# Завантажити будь який архів з даними (csv). Архів має містити деякі чисельні показники.
# (я обрала ""

# Завантажуємо CSV-файл
csv_file_path = 'MCUD-dec20-marriage-rate-and-divorce-rate.csv'

# Використовуємо Pandas для читання CSV-файлу
df = pd.read_csv(csv_file_path)

# Весь вміст CSV-файлу тепер доступний в об'єкті 'df'


# Виводимо весь вміст на екран
print(df)

"""
# Виводимо перші кілька рядків для перевірки
print(df.head(10))
"""
