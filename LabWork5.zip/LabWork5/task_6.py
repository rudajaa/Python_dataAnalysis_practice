from sklearn import datasets
from sklearn.cluster import Birch
import matplotlib.pyplot as plt

# Завантаження датасету ірисів Фішера
iris = datasets.load_iris()
data = iris.data  # Ознаки ірисів



# Виконання кластерного аналізу методом BIRCH
birch = Birch(n_clusters=3, threshold=0.5)
birch.fit(data)



# Отримання міток кластерів
labels = birch.labels_
centroids = birch.subcluster_centers_

# Розділення даних за кластерами
cluster1 = data[labels == 0]
cluster2 = data[labels == 1]
cluster3 = data[labels == 2]

# Відображення кластерів та їх центрів
plt.scatter(cluster1[:, 0], cluster1[:, 1], c='b', label='Cluster 1')
plt.scatter(cluster2[:, 0], cluster2[:, 1], c='g', label='Cluster 2')
plt.scatter(cluster3[:, 0], cluster3[:, 1], c='r', label='Cluster 3')
plt.scatter(centroids[:, 0], centroids[:, 1], c='k', marker='x', s=100, label='Centroids')
plt.legend(loc='best')
plt.xlabel('Ознака 1')
plt.ylabel('Ознака 2')
plt.title('Кластерний аналіз методом BIRCH для ірисів Фішера')
plt.show()
