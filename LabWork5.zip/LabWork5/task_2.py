import csv
import matplotlib.pyplot as plt

# Побудувати гістограми для будь-якого стовпця для вашої матриці,
# Використав різні аргументи hist

data = []

# Завантажуємо дані з CSV-файлу

with open('data_population.csv', 'r') as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        data.append([float(value) for value in row])

column_data = [row[0] for row in data]

# Будуємо гістограму
plt.hist(column_data, bins=20, edgecolor='black', alpha=0.5, facecolor='pink', linewidth=1.2)
plt.xlabel('М`ясо (кг)')  # підпис для осі x
plt.ylabel('Країни')  # підпис для осі y
plt.title('Гістограма залежності країн від м`яса')  # заголовок гістограми
plt.show()
