# Виконати кластерний аналіз вихідних даних методами K-середніх і BIRCH

import pandas as pd
from sklearn.cluster import KMeans, Birch
import matplotlib.pyplot as plt

# Завантаження даних
csv_file_path = 'MCUD-dec20-marriage-rate-and-divorce-rate.csv'
df = pd.read_csv(csv_file_path)

# Вибірка 1 і 3 стовпців
selected_column_1 = df.iloc[:, [0]]  # стовпчик 3 (рік)
selected_column_3 = df.iloc[:, [2]]  # стовпчик 3 (розлучення/весілля)

# Виконання кластерного аналізу методом K-середніх
kmeans_3 = KMeans(n_clusters=3, n_init=10)
kmeans_9 = KMeans(n_clusters=9, n_init=10)

kmeans_3.fit(selected_column_1)
kmeans_9.fit(selected_column_3)

# Виконання кластерного аналізу методом BIRCH
birch_3 = Birch(n_clusters=3)
birch_5 = Birch(n_clusters=5)

birch_3.fit(selected_column_1)
birch_5.fit(selected_column_3)

# Виведення результатів
print("K-Means (3 кластери):")
print(kmeans_3.labels_)

print("K-Means (9 кластерів):")
print(kmeans_9.labels_)

print("BIRCH (3 кластери):")
print(birch_3.labels_)

print("BIRCH (5 кластерів):")
print(birch_5.labels_)

# Графік для BIRCH (3 кластери)
plt.figure(figsize=(8, 6))
plt.scatter(selected_column_1, selected_column_3, c=birch_3.labels_, cmap='rainbow')
plt.title(" Кластерний аналіз методом BIRCH (3 кластери)")
plt.xlabel("Рік")
plt.ylabel("Розлучення/весілля")
plt.show()

# Графік для BIRCH (5 кластерів)
plt.figure(figsize=(8, 6))
plt.scatter(selected_column_1, selected_column_3, c=birch_5.labels_, cmap='rainbow')
plt.title("Кластерний аналіз методом BIRCH (5 кластерів)")
plt.xlabel("Рік")
plt.ylabel("Розлучення/весілля")
plt.show()





