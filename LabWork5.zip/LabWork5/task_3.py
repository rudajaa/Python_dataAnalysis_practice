import csv
import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import Birch

# Виконати кластерний аналіз вихідних даних методом BIRCH.

# Завантажуємо дані з CSV-файлу
data = []
with open('data_population.csv', 'r') as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        data.append([float(x) for x in row])

data = np.array(data)  # Перетворюємо список у масив numpy

# Виконання кластерного аналізу методом BIRCH
birch = Birch(threshold=0.01, branching_factor=50)
birch.fit(data)

# Отримання міток кластерів для кожного прикладу
cluster_labels = birch.labels_

# Виведення результатів
for i, label in enumerate(cluster_labels):
    print(f"Країна {i + 1} належить до кластера {label}")

# Побудова графіка
plt.scatter(data[:, 3], data[:, 2], c=cluster_labels, cmap='rainbow', s=40)
plt.xlabel('Алкоголь (літр)')
plt.ylabel('Кількість лікарів на 10000 населення')
plt.title('Кластеризація методом BIRCH')
plt.show()
