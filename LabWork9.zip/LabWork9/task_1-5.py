import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import norm
import numpy as np

# 1. Завантажити дані для обробки;
# Завантаження даних з CSV файлу
file_path = 'data.csv'
data = pd.read_csv(file_path, header=None, names=['X2', 'X3'])

# Виведення рядків для перевірки
print(data.head(50))

# 2. Обчислити статистичні оцінки;
# Обчислення статистичних оцінок для кожної колонки
stats = data.describe()

# Виведення статистичних оцінок
print("Статистичні оцінки")
print(stats)

# 3. Побудувати гістограми.
# Побудова гістограми для першої колонки
plt.hist(data['X2'], bins=10, color='magenta', edgecolor='black')
plt.title('Гістограма для X2')
plt.xlabel('Значення')
plt.ylabel('Частота')
plt.show()

# Побудова гістограми для другої колонки
plt.hist(data['X3'], bins=10, color='yellow', edgecolor='black')
plt.title('Гістограма для X3')
plt.xlabel('Значення')
plt.ylabel('Частота')
plt.show()

# 4. Виконати апроксимацію гістограм нормальним законом.
# Функція для апроксимації гістограми нормальним законом

# 5. На основі аналізу гістограми встановити граничне значення показника при якому розділити
# дані та позначити його на нашому графіку.

def fit_and_plot(data, column_name):
    # Отримання середнього та стандартного відхилення
    mu, std = norm.fit(data[column_name])

    # Побудова гістограми
    plt.hist(data[column_name], bins=10, density=True, alpha=0.6, color='pink', edgecolor='black')

    # Відтворення функції щільності ймовірності за нормальним законом
    xmin, xmax = plt.xlim()
    x = np.linspace(xmin, xmax, 100)
    p = norm.pdf(x, mu, std)
    plt.plot(x, p, 'k', linewidth=2)

    # Визначення граничного значення (медіана) та позначення на графіку
    median_value = data[column_name].median()
    plt.axvline(median_value, color='red', linestyle='dashed', linewidth=2, label=f'Границя: {median_value:.2f}')

    # Додавання текстової інформації до графіку
    title = f'Апроксимація за нормальним законом: {column_name}\nСереднє={mu:.2f}, Стандартне відхилення={std:.2f}'
    plt.title(title)
    plt.xlabel('Значення')
    plt.ylabel('Щільність ймовірності')
    plt.show()

# Викликаємо функцію для обох колонок
fit_and_plot(data, 'X2')
fit_and_plot(data, 'X3')


