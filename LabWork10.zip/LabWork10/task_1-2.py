# 1. Визначити для вхідних змінних середнє значення, дисперсію, стандартне відхилення, ковараційну
# та кореляційну матриці. Визначити взаємозалежні ознаки для заданої матриці Х «об'єкт-властивість».

import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# Створюємо DataFrame з даними
data = {
    'Експерименти': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    'X1': [1.09, 9.99, 5.89, 6.73, 2.45, 4.67, 5.89, 8.33, 2.67, 1.73],
    'Зміна стану y': [79.4, 61.1, 78.8, 60.5, 88.4, 76.0, 88.0, 79.4, 79.9, 64.6]
}

df = pd.DataFrame(data)

# Виводимо DataFrame
print(df)

# Середнє значення
mean_values = df.mean()
print("Середнє значення:\n", mean_values)

# Дисперсія
variance_values = df.var()
print("\nДисперсія:\n", variance_values)

# Стандартне відхилення
std_deviation_values = df.std()
print("\nСтандартне відхилення:\n", std_deviation_values)

# Ковараційна матриця
covariance_matrix = df.cov()
print("\nКовараційна матриця:\n", covariance_matrix)

# Кореляційна матриця
correlation_matrix = df.corr()
print("\nКореляційна матриця:\n", correlation_matrix)

# Кореляція між X1 і Зміна стану y
correlation_xy = df['X1'].corr(df['Зміна стану y'])
print(f"\nКореляція між X1 і Зміна стану y: {correlation_xy}")

# 2. Побудувати лінійну парну регресійну модель (Таблиця 4.5, X1, y), знайти коефіцієнти моделі.
# Побудувати графік вихідних даних та апроксимуючої функції. Графіки повинні мати заголовки, легенду та підписи осей.

# Визначаємо незалежну змінну (X) і залежну змінної (y)
X = df[['X1']]
y = df['Зміна стану y']

# Створення та тренування моделі
model = LinearRegression()
model.fit(X, y)

# Виведення коефіцієнтів моделі
slope = model.coef_[0]
intercept = model.intercept_
print(f"Коефіцієнт нахилу (slope): {slope}")
print(f"Вільний член (intercept): {intercept}")

# Побудова графіку
plt.scatter(X, y, color='orange', label='Вихідні дані')
plt.plot(X, model.predict(X), color='k', linewidth=2, label='Лінійна регресія')
plt.title('Лінійна регресія та апроксимація')
plt.xlabel('X1')
plt.ylabel('Зміна стану y')
plt.legend()
plt.show()

