# 3. Визначити для вихідної залежної змінної середнє значення, дисперсію, коефіцієнти кореляції,
# стандартного відхилення.

import pandas as pd
import numpy as np
from statistics import mean, stdev
import seaborn as sns
import matplotlib.pyplot as plt

# Створюємо DataFrame з даними
data = {
    'Експерименти': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    'X1': [1.09, 9.99, 5.89, 6.73, 2.45, 4.67, 5.89, 8.33, 2.67, 1.73],
    'Зміна стану y': [79.4, 61.1, 78.8, 60.5, 88.4, 76.0, 88.0, 79.4, 79.9, 64.6]
}

# Створення DataFrame з даними
df = pd.DataFrame(data)

# Виведення середнього значення, дисперсії та стандартного відхилення для кожного стовпця
for col in df.columns[1:]:
    print(f'{col}:')
    print(f'Середнє: {mean(df[col])}')
    print(f'Дисперсія: {np.var(df[col])}')
    print(f'Стандартне відхилення: {stdev(df[col])}')
    print()

# Виведення коефіцієнта кореляції між X1 та Зміна стану y
correlation_coefficient = np.corrcoef(df['X1'], df['Зміна стану y'])[0, 1]
print(f'Коефіцієнт кореляції між X1 та Зміна стану y: {correlation_coefficient}')

# 4. Візуалізувати матрицю кореляції.

# Обчислення матриці кореляції
correlation_matrix = df.corr()

# Візуалізація теплокартою
plt.figure(figsize=(8, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='cividis', fmt=".2f", linewidths=.5)
plt.title('Матриця кореляції')
plt.show()

# Візуалізація pair plot
sns.pairplot(df)
plt.suptitle('Pair Plot з матрицею кореляції', y=1.02)
plt.show()

