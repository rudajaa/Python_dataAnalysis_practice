from sklearn.preprocessing import StandardScaler
import numpy as np
from scipy.spatial.distance import pdist

# Зчитати дані з файлу
with open("investment_data.txt", "r") as file:
    lines = file.readlines()


# Розділяємо рядки та перетворюємо дані у масив NumPy
data = []
for line in lines:
    row = line.strip().split()
    data.append([float(x.replace(',', '.')) for x in row])

# Перетворюємо список у масив NumPy
data = np.array(data)

# Створюємо екземпляр StandardScaler
scaler = StandardScaler()

# Нормуємо дані за допомогою StandardScaler
normalized_data = scaler.fit_transform(data)

#3. Обчислити відстані між об`єктами за допомогою функції pdist.
#Використовувати заходи для розрахунку відстаней згідно з варіантом (Евклідова, Манхеттенська,Евклідова ).

# Обчислюємо відстані за допомогою евклідової метрики
distances_euclidean = pdist(normalized_data, metric='euclidean')

# Обчислюємо відстані за допомогою манхеттенської метрики (міста)
distances_cityblock = pdist(normalized_data, metric='cityblock')

# Обчислюємо ще одну евклідову відстань
distances_euclidean2 = pdist(normalized_data, metric='euclidean')

print("Евклідова метрика")
print(distances_euclidean)

print("Манхеттенська метрика (міста)")
print(distances_cityblock)

print("Евклідова метрика 2")
print(distances_euclidean2)

