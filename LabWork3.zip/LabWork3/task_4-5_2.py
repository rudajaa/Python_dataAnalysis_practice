from sklearn.preprocessing import StandardScaler
import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial.distance import pdist
from scipy.cluster.hierarchy import linkage, dendrogram, fcluster

# Зчитати дані з файлу
with open("investment_data.txt", "r") as file:
    lines = file.readlines()

# Розділяємо рядки та перетворюємо дані у масив NumPy
data = []
for line in lines:
    row = line.strip().split()
    data.append([float(x.replace(',', '.')) for x in row])

# Перетворюємо список у масив NumPy
data = np.array(data)

# Створюємо екземпляр StandardScaler
scaler = StandardScaler()

# Нормуємо дані за допомогою StandardScaler
normalized_data = scaler.fit_transform(data)

# Обчислюємо відстані за допомогою евклідової метрики
distances_euclidean = pdist(normalized_data, metric='euclidean')

# Обчислюємо відстані за допомогою манхеттенської метрики (міста)
distances_cityblock = pdist(normalized_data, metric='cityblock')

# Обчислюємо ще одну евклідову відстань
distances_euclidean2 = pdist(normalized_data, metric='euclidean')


#4. Виконати кластерний аналіз вихідних даних методом ієрархічної
#кластеризації за методами зв`язування згідно з варіантом (Метод ближнього сусіда, Метод далекого сусіда, Метод центроїдного зв'язку ).
#Використовувати перший приклад та функцію linkage.
#5. Побудувати дендрограму.


# Метод далекого сусіда
# Обчислюємо зв'язки методом далекого сусіда
linkage_matrix_complete = linkage(distances_euclidean, method='complete')

# Відображення дендрограми
plt.figure(figsize=(12, 6))
dendrogram(linkage_matrix_complete)
plt.title('Дендрограма (Далекий сусід)')
plt.show()

# Визначаємо кількість кластерів, наприклад, 3
num_clusters_complete = 3

# Виконуємо кластеризацію
clusters_complete = fcluster(linkage_matrix_complete, num_clusters_complete, criterion='maxclust')

# Виводимо результати кластеризації
print("Результати кластеризації (Далекий сусід):")
print(clusters_complete)