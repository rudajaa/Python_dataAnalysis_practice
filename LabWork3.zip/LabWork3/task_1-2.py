

from sklearn.preprocessing import StandardScaler
import numpy as np
import matplotlib.pyplot as plt


# 1. Створити текстовий файл (наприклад,
# у програмі Блокнот) та зберегти в ньому
# матрицю вихідних даних згідно з варіантом. Завантажити дані із текстового файлу.

# Зчитати дані з файлу
with open("investment_data.txt", "r") as file:
    lines = file.readlines()

# 2. Виконати нормування даних та побудувати графічне зображення на
#площині деякі пари ознак експериментальних даних.

# Розділяємо рядки та перетворюємо дані у масив NumPy
data = []
for line in lines:
    row = line.strip().split()
    data.append([float(x.replace(',', '.')) for x in row])

# Перетворюємо список у масив NumPy
data = np.array(data)

# Створюємо екземпляр StandardScaler
scaler = StandardScaler()

# Нормуємо дані за допомогою StandardScaler
normalized_data = scaler.fit_transform(data)
print("Нормовані дані")
print(normalized_data)


# Оберемо дві ознаки (стовпці) для візуалізації, наприклад, Risk та Tax
feature1 = normalized_data[:, 2]
feature2 = normalized_data[:, 5]


# Будуємо графік
plt.scatter(feature1, feature2, c="orange", label='Дані')
plt.xlabel('Risk')
plt.ylabel('Tax ')
plt.title('Залежність ознак Risk та Tax')
plt.legend()
plt.grid(True)
plt.show()



