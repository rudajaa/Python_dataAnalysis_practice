# 1. Побудувати варіаційний ряд (дискретний та інтервальний);

import numpy as np
import matplotlib.pyplot as plt

data = np.array([
    17.6, 20.1, 21.2, 25.2, 20.4, 19.7, 19.1, 21.5, 22.5, 19.2,
    20.7, 20.8, 16.3, 18.8, 25.0, 19.1, 19.7, 16.9, 15.6, 22.1,
    22.2, 26.9, 19.0, 22.6, 21.5, 15.5, 18.0, 18.0, 15.5, 21.0,
    22.4, 18.0, 17.7, 15.8, 19.2, 15.4, 18.9, 20.2, 24.4, 17.4,
    23.2, 18.5, 18.1, 20.3, 17.1, 22.9, 22.6, 18.4, 20.8, 22.3,
    13.9, 14.2, 23.2, 20.2, 18.6, 16.1, 19.3, 17.4, 20.8, 23.4,
    22.5, 21.7, 19.9, 22.1, 18.2, 17.3, 18.9, 26.2, 19.4, 22.1,
    24.5, 19.4, 20.6, 23.3, 18.8, 22.3, 24.5, 24.9, 21.5, 23.3,
    20.6, 18.6, 15.8, 16.4, 25.4, 23.9, 19.1, 19.9, 16.4, 19.2,
    20.2, 18.0, 20.3, 22.6, 20.7, 24.7, 17.8, 18.3, 23.3, 22.0
])


unique_values, value_counts = np.unique(data, return_counts=True)

discrete_variation = np.array([unique_values]).T

print("Дискретний варіаційний ряд:")
print(discrete_variation)


# Знаходимо мінімальне та максимальне значення
min_value = min(data)
max_value = max(data)

# Визначаємо кількість інтервалів (формула Стерджеса)
num_intervals = int(1 + 3.322 * np.log10(len(data)))

# Обчислюємо ширину інтервалів
interval_width = (max_value - min_value) / num_intervals

# Будуємо інтервальний ряд та підраховуємо кількість значень в кожному інтервалі
intervals = [min_value + i * interval_width for i in range(num_intervals + 1)]
hist, _ = np.histogram(data, bins=intervals)
print("")
print("Інтервальний варіаційний ряд:")

# Виводимо інтервал, кількість значень та інтервальний ряд
for i in range(num_intervals):
    print(f'Інтервал {i + 1}: {intervals[i]:.2f} - {intervals[i + 1]:.2f}, '
          f'Кількість значень: {hist[i]}')


# 2. Обчислити відносні частоти (частості) та накопичені частоти;
# Знаходимо загальну кількість значень в вихідних даних
total_count = len(data)

# Ініціалізуємо пусті списки для відносних частот і накопичених частот
relative_frequencies = []
cumulative_frequencies = []

# Обчислюємо відносні частоти та накопичені частоти
cumulative_count = 0
for count in hist:
    relative_frequency = count / total_count
    cumulative_count += count
    cumulative_frequency = cumulative_count / total_count
    relative_frequencies.append(relative_frequency)
    cumulative_frequencies.append(cumulative_frequency)

# Виводимо результати
print("")
for i in range(num_intervals):
    print(f'Інтервал {i + 1}: {intervals[i]:.2f} - {intervals[i + 1]:.2f}, '
          f'Частість: {relative_frequencies[i]:.4f}, '
          f'Накопичена частість: {cumulative_frequencies[i]:.4f}')


# 3. Побудувати графіки варіаційного ряду (полігони та гістограми
# відносних та абсолютних частот);

# Побудова графіків
plt.figure(figsize=(12, 6))

# Полігон відносних частот
plt.subplot(2, 2, 1)
plt.plot(intervals[:-1], relative_frequencies, marker='o', linestyle='-')
plt.title('Полігон відносних частот')
plt.xlabel('Інтервали')
plt.ylabel('Відносні частоти')

# Гістограма абсолютних частот
plt.subplot(2, 2, 2)
plt.bar(intervals[:-1], hist, width=interval_width, align='edge')
plt.title('Гістограма абсолютних частот')
plt.xlabel('Інтервали')
plt.ylabel('Абсолютні частоти')

# Полігон абсолютних частот
plt.subplot(2, 2, 3)
plt.plot(intervals[:-1], hist, marker='o', linestyle='-')
plt.title('Полігон абсолютних частот')
plt.xlabel('Інтервали')
plt.ylabel('Абсолютні частоти')

# Гістограма відносних частот
plt.subplot(2, 2, 4)
plt.bar(intervals[:-1], relative_frequencies, width=interval_width, align='edge')
plt.title('Гістограма відносних частот')
plt.xlabel('Інтервали')
plt.ylabel('Відносні частоти')

plt.tight_layout()
plt.show()