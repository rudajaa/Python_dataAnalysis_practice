import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm, gamma
from scipy.optimize import curve_fit

#  дані
data = [-2, 1, -1, 5, 5, 1, 3, -2, 3, 4, 2, -2, -2, 4, -2, -2, 2, 0, -1, -1, -1, 3, 4, -1, 2, 0, 1, -1, 2, 5, 4, 2, -1, 5, 1, -1, 2, 3, -1, 1, 5, 3, 2, -1, -1, -1, -2, 2, -2, 2]

# Побудова гістограми
plt.hist(data, bins=10, density=True, alpha=0.6, color='b', label='Гістограма')

# Визначення середнього та стандартного відхилення для апроксимації Гауссовим розподілом
mean, std = np.mean(data), np.std(data)

# Функція для апроксимації Гауссовим розподілом
def gaussian(x, a, x0, sigma):
    return a * np.exp(-(x - x0) ** 2 / (2 * sigma ** 2))

# Проведення апроксимації Гауссовим розподілом
x = np.linspace(-5, 10, 100)
params, covariance = curve_fit(gaussian, x, norm.pdf(x, loc=mean, scale=std))
a, x0, sigma = params
plt.plot(x, gaussian(x, a, x0, sigma), 'r', label='Апроксимація Гауссовим розподілом')


# Видалення від'ємних та нульових значень
filtered_data = [x for x in data if x > 0]

# Апроксимація гамма-розподілом на очищених даних
shape, loc, scale = gamma.fit(filtered_data, floc=0)
gamma_dist = gamma(shape, loc=loc, scale=scale)
plt.plot(x, gamma_dist.pdf(x), 'g', label='Апроксимація гамма-розподілом')

plt.legend()
plt.xlabel('Значення')
plt.ylabel('Ймовірність')
plt.title('Гістограма та апроксимація розподілів')
plt.show()