import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
from collections import Counter
from scipy.stats import norm, expon, gamma, chi2


# 1. Побудувати за даною вибіркою статистичний розподіл, обчислити статистичні оцінки. Вивести усі ці значення на екран.

#  Дані
data = np.array([-2, 1, -1, 5, 5, 1, 3, -2, 3, 4, 2, -2, -2, 4, -2, -2, 2,
                 0, -1, -1, -1, 3, 4, -1, 2, 0, 1, -1, 2, 5, 4, 2, -1, 5, 1,
                 -1, 2, 3, -1, 1, 5, 3, 2, -1, -1, -1, -2, 2, -2, 2])

# Рахуємо частоти
frequency = Counter(data)

# Виводимо таблиці частот
print('Таблиця частот:')
for value, count in sorted(frequency.items()):
    print(f"Значення {value}: {count} рази")


# Розрахунок статистичних оцінок
mean = np.mean(data)
median = np.median(data)
mode = stats.mode(data)
variance = np.var(data)
std_deviation = np.std(data)
range_ = np.ptp(data)
skewness = stats.skew(data)
kurtosis = stats.kurtosis(data)

# Вивід статистичних оцінок
print("")
print(f'Статистичні оцінки:')
print(f'Середнє значення: {mean}')
print(f'Медіана: {median}')
print(f'Мода: {mode[0]}')
print(f'Дисперсія: {variance}')
print(f'Стандартне відхилення: {std_deviation}')
print(f'Розмах: {range_}')
print(f'Коефіцієнт асиметрії (скос): {skewness}')
print(f'Коефіцієнт ексцесу (крутість): {kurtosis}')


# 2. Побудувати гістограму.
# Побудова гістограми
plt.hist(data, bins=10, edgecolor='k', alpha=0.65)
plt.title('Гістограма вибірки')
plt.xlabel('Значення')
plt.ylabel('Частота')
plt.grid(False)
plt.show()

# 3. Підібрати закон розподілу випадкової величини
# Вибираємо розподіл для порівняння
distributions = [norm, expon, gamma, chi2]
distribution_names = ['Нормальний', 'Експоненціальний', 'Гамма', 'Розподіл хі-квадрат']

# Побудова гістограми
plt.hist(data, bins=20, density=True, alpha=0.6, color='g', label='Гістограма')

# Порівняння з розподілами
for distribution, name in zip(distributions, distribution_names):
    params = distribution.fit(data)
    pdf = distribution.pdf(np.sort(data), *params)
    plt.plot(np.sort(data), pdf, label=name)

plt.legend()
plt.title("Порівняння з різними розподілами")
plt.xlabel("Значення")
plt.ylabel("Щільність ймовірності")
plt.show()
