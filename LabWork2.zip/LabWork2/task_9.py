# 9. Побудувати тривимірний графік матриці А в залежності від номера елемента по рядках та
#стовпцях з використанням різної палітри кольорів і з можливістю повертати зображення під
#різними ракурсами.

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import Normalize

# Матриця A
matrix_A = np.array([
    [0.876, 0.772, 0.758, 0.800, 0.796, 0.666, 0.98],
    [0.355, 0.620, 0.931, 0.867, 0.871, 0.755, 0.96],
    [0.906, 0.990, 0.951, 0.989, 0.964, 0.866, 0.85],
    [0.979, 0.998, 0.991, 0.945, 0.937, 0.937, 0.91],
    [0.997, 0.963, 0.927, 0.865, 0.998, 0.86, 0.88],
    [0.992, 0.999, 1.000, 0.985, 0.932, 0.99, 0.46],
    [0.782, 0.612, 0.996, 0.763, 0.893, 0.97, 0.57]
])

# Отримуємо розмірність матриці
nrows, ncols = matrix_A.shape

# Створюємо координати для рядків і стовпців матриці
x = np.arange(nrows)
y = np.arange(ncols)
x, y = np.meshgrid(x, y)
x = x.flatten()
y = y.flatten()

# Отримуємо значення матриці A у вигляді 1D масиву
z = matrix_A.flatten()

# Створюємо кольори для кожного стовпчика
norm = Normalize(z.min(), z.max())
colors = plt.cm.viridis(norm(z))

# Створюємо тривимірний графік
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Побудова тривимірного графіку з різнокольоровими стовпчиками
ax.bar3d(x, y, np.zeros_like(z), 1, 1, z, shade=True, color=colors)

# Налаштування вигляду графіка
ax.set_xlabel('Рядки')
ax.set_ylabel('Стовпці')
ax.set_zlabel('Значення')


# Вивід графіка
plt.show()

